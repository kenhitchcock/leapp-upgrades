# Review Checklist

Refer to the [Collection review checklist](https://github.com/ansible/community-docs/blob/main/review_checklist.rst).
